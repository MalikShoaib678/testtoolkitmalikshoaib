#Used Libraries
from termcolor import colored
import requests
from bs4 import BeautifulSoup as bs
import urllib.parse
import threading
import time
import sys

class Scanner:
    session = requests.Session()
    web_directories = []
    target_links    = []
    subdomain_list  = []
    def __init__(self, url):
        self.target = url
        
    #Gets token to submit Form..
    def get_token(self, url):
        response = self.session.get(url)
        parsed_response = bs(response.content, 'html.parser')
        forms = parsed_response.findAll('form')
        for form in forms:
            inputs = form.findAll('input')
            for input in inputs:
                if input.get('name') == 'user_token':
                    token = input.get('value')
                    return token
                    
    #This method is used to logon to website..
    def login(self, url, login_data):
        print("\n[+] Login Finished:")
        token = self.get_token(url)
        login_dict = login_data
        login_dict['user_token'] = token
        self.session.post(url, data=login_dict)
        return True
    
    #adds elements to list
    def add_toList(self, link):
        self.target_links.append(link)
    
class Crawler(Scanner):
    def __init__(self, url):
        super().__init__(url)
        self.n = 1
        
    #Spider tool    
    def spidy(self, url=None):
        try:
            if url == None:
                url = self.target
            response = self.session.get(url)
            parsed_response = bs(response.content, 'html.parser')
            elements = parsed_response.findAll('a')
            for element in elements:
                link = element.get('href')
                link = urllib.parse.urljoin(url, link)
                if '#' in link:
                    link = link.split('#')[0]
                if url in link and link not in self.target_links and 'logout' not in link:
                    print( f"[{self.n}]\t" + link)
                    self.n = self.n + 1
                    self.target_links.append(link)
                    self.spidy(link)
                    
        except KeyboardInterrupt:
                print("[*] Exiting....tool")
                sys.exit(0)        
    
    #Shows Options            
    def show_options(self):
        print(colored("[*] Available Options:", "green"))
        print(colored("+----------------------+------------------------------------+-------------------------------+", "green"))
        print(colored("| Options              | Current Setting        |  Required        | Description            |", "green"))
        print(colored("+----------------------+------------------------------------+-------------------------------+", "green"))     
        print(colored(f"| target               | {self.target.ljust(23)}|     Yes          | Your Target            |", "cyan"))
        print(colored("+----------------------+------------------------+------------------+-------------------------+", "green"))

    #Runs Spider tool    
    def runSpider(self):
        print(colored("\n[+] Crawling Links...",'green'))
        self.spidy()
        print(colored("[+] Crawled Links...",'green'))
        
class VulnScanner(Scanner): 
    def __init__(self, url, target_urls, vuln_payloads_file):
        super().__init__(url)
        self.n = 1
        #TargetURLs
        self.target_urls = open(target_urls, 'r')
        for Turl in self.target_urls.readlines():
            Turl = Turl.strip('\n')
            self.target_links.append(Turl)
        
        #PAYLOADS_______________________________
        self.vuln_payloads = []
        payload_block = open(vuln_payloads_file, "r")
        for payload in payload_block.readlines():
            payload = payload.strip('\n')
            self.vuln_payloads.append(payload)
        try:
            self.urls_file = target_urls.split("/")[-1]
        except:
            self.urls_file = "None"
    
            
        try:
            self.wordlist_name = vuln_payloads_file.split("/")[-1]
        except:
            self.wordlist_name = "None"
    
    #Gets total total number of from from file        
    def getFileLength(self):
        try:
            with open(file, 'r') as directories:
                length = directories.readlines()
                return str(len(length))
        except:
            return "None"
    #Shows options    
    def show_options(self):
        print(colored("[*] Available Options:", "green"))
        print(colored("+----------------------+------------------------------------+-------------------------------+", "green"))
        print(colored("| Options              | Current Setting        |  Required        | Description            |", "green"))
        print(colored("+----------------------+------------------------------------+-------------------------------+", "green"))     
        print(colored(f"| target_urls          | {self.urls_file.ljust(23)}|    Yes           | Your Target            |", "cyan"))
        print(colored(f"| Url's     >   >   >  | {str(len(self.target_links)).ljust(23)}|    IdK           |shows length of wordlist|", "cyan"))
        print(colored(f"| payload_file         | {self.wordlist_name.ljust(23)}|    Yes           | your Payloads          |", "cyan"))
        print(colored(f"| Payloads  >   >   >  | {str(len(self.vuln_payloads)).ljust(23)}|    IdK           |shows length of wordlist|", "cyan"))
        #print(colored(f"| threads              | {str(self.speed).ljust(23)}|    Yes           | Threads                |", "cyan"))
        print(colored("+----------------------+------------------------+------------------+-------------------------+", "green"))
        
        
    #Extracts Forms...
    def extractForms(self, url):
        response = self.session.get(url).content
        parsed_response = bs(response, 'html.parser')
        forms = parsed_response.findAll('form')
        return forms
        
    #Submits Form
    def submitForm(self, form, url, value):
        postData = {}
        #Gets basic Form information
        action = form.get('action')
        method = form.get('method')
        postUrl = urllib.parse.urljoin(url, action)
        #Extracts inputs from page
        inputs = form.findAll('input')
        for input in inputs:
            #Gets input details
            inputName = input.get('name')
            inputValue= input.get('value')
            postData[inputName] = inputValue
            
            #Checks input type and sets payload
            if input.get('type') == 'text':
                postData[inputName] = value
            postData['user_token'] = self.get_token(url)
            
            #Checks method type
            if method == 'GET':
                return self.session.get(postUrl, params=postData)
            else :
                return self.session.post(postUrl, data=postData)
                
    #Builds links for scanning injection
    def buildUrl(self, link):
        response = self.session.get(link)
        parse = bs(response.content, 'html.parser')
        forms = parse.findAll('form')
        for form in forms:
            inputs = form.findAll('input')
            for input in inputs:
                input_name = input.get('name')
                if input.get('type') == 'text':
                    name = input_name
        getUrl = link + '?' + name + '='
        return getUrl
        
    #vuln_in links
    def vulnLinks(self, urlTest, payload):
        url = urlTest
        url = url.replace('=', '=' + payload)
        print(colored(f'[{self.n}]\t' + '[+] Testing link ' + url , 'green'))
        self.n = self.n +1
        data= {'user_token' : self.get_token(url)}
        response = self.session.get(url, params=data).content.decode()
        response_htmlDecoding = response.replace('&lt;','<').replace('&gt;', '>')
        if payload in response:
            print(colored(f"[{self.n}]\t" + '[+] Target link :' + url + ' is vulnerable'  , 'red'))
        elif payload in response_htmlDecoding:
            print(colored(f"[{self.n}]\t" + '[+] Target link :' + url + ' is using HTML encoding'  , 'cyan'))
            
    #vuln in Forms  
    def vulnForms(self, form, link, payload):
        print(colored(f"[{self.n}]\t" + '[+] Testing form in ' + link  , 'blue'), 'with :' + payload)
        self.n = self.n + 1
        response= self.submitForm(form, link, payload).content.decode()
        htmldecoded_response = response.replace('&lt;','<').replace('&gt;', '>')
        
        if payload in response:
            print(colored(f"[{self.n}]\t" + '[+] Form in :' + link + ' is vulnerable' , 'red'))
        elif payload in htmldecoded_response:
            print(colored(f"[{self.n}]\t" + '[+] Target Form in  :' + link + ' is using HTML encoding'  , 'cyan'))
        #Scan.for.vuln
    
    #Manages links and payloafs
    def vulnScanner(self, link, payload):
        try:
            if "=" not in link:
                getlink = self.buildUrl(link)
            else:
                getlink = link
            if '=' in getlink:
                vulnerability = self.vulnLinks(getlink, payload)
        except:
            pass
        forms = self.extractForms(link)
        for form in forms:
            vulnerability = self.vulnForms(form, link, payload)
            
    #Runs vulnerabilityScanner                
    def runScanner(self, speed):
        print(colored("\n[+] Checking Injection..", 'red'))
        threads = []
        for target_link in self.target_links:
            for payload in self.vuln_payloads:
                try:
                    thread = threading.Thread(target=self.vulnScanner, args=(target_link, payload,))
                    threads.append(thread)
                    thread.start()
                    if len(threads) == 1:
                        for thread in threads:
                            thread.join()
                        threads = []
                        
                except KeyboardInterrupt:
                    print("[*] Exiting....tool")
                    return 
        #for thread in threads:
            thread.join()

class dirScanner(Scanner):
    def __init__(self, url, wordlist, speed):
        self.wordlist = wordlist
        self.speed    = speed
        self.length   = None
        self.url      = url
        self.i        = 1
        
        
        try:
            self.wordlist_name = self.wordlist.split("/")[-1]
        except:
            self.wordlist_name = "None"
    
    #Gets total total number of from from file        
    def getFileLength(self):
        try:
            with open(self.wordlist, 'r') as directories:
                length = directories.readlines()
                return str(len(length))
        except:
            return "None"
            
    #Sends requests and analysis response 
    def get(self, url):
        response = []
        try:
            if self.length == None:
                length = self.getFileLength()
            try:
                res = requests.get(url)
            except:
                self.get(url)
            response.append(url)
            response.append(res.status_code)
            if res.status_code == 200:
                time.sleep(0.2)
                print("".ljust(60), end='\r')
                time.sleep(0.2)
                print(colored(f"[{self.i}]\t{str(response[1]).ljust(5)} : {response[0].ljust(60)}", 'green'))
                self.web_directories.append(response[0])
            elif res.status_code == 404:
                print(f"[{self.i}/{length}]\t{str(response[1]).ljust(5)} : {response[0].ljust(60)}", end="\r")
                    
            else:
                time.sleep(0.2)
                print("".ljust(60), end='\r')
                time.sleep(0.2)
                print(colored(f"[{self.i}]\t{str(response[1]).ljust(5)} : {response[0].ljust(60)}", 'blue'))
                self.web_directories.append(response[0])
            self.i = self.i + 1
        except:
            print(f"\r[{self.i}]\t{str(response[1]).ljust(5)} No internet connection!", end="\r")
            self.i = self.i + 1
        
    # Manages Threads, file and link
    def scanner(self, url, wordlist, speed):
        with open(wordlist, 'r') as directories:
            threads = []
            for directory in directories.readlines():
                try:
                    directory = directory.strip('\n')
                    test_url = url + directory
                    
                    thread = threading.Thread(target=self.get, args=(test_url,))
                    threads.append(thread)
                    thread.start()
                    if len(threads) == speed:
                        for thread in threads:
                            thread.join()
                        threads = []
                        
                except KeyboardInterrupt:
                    threads = []
                    print("[*] Exiting....tool")
                    return
        for thread in threads:
            thread.join()
    #Shows options
    def show_options(self):
        print(colored("[*] Available Options:", "green"))
        print(colored("+----------------------+------------------------------------+-------------------------------+", "green"))
        print(colored("| Options              | Current Setting        |  Required        | Description            |", "green"))
        print(colored("+----------------------+------------------------------------+-------------------------------+", "green"))     
        print(colored(f"| target               | {self.url.ljust(23)}|    Yes           | Your Target            |", "cyan"))
        print(colored(f"| wordlist             | {self.wordlist_name.ljust(23)}|    Yes           | your Wordlist          |", "cyan"))
        print(colored(f"| sizeOfWordlist       | {self.getFileLength().ljust(23)}|    IdK           |shows length of wordlist|", "cyan"))
        print(colored(f"| threads              | {str(self.speed).ljust(23)}|    Yes           | Threads                |", "cyan"))
        print(colored("+----------------------+------------------------+------------------+-------------------------+", "green"))

    #Runs Wordlist attack       
    def runBruteScan(self):
        print(colored("[+] Started Directory scanning...\n",'green'))
        self.scanner(self.url, self.wordlist, self.speed)
        print(colored("[+] Finished Directory scanning...\n",'green'))

class subdomainScanner(Scanner):
    def __init__(self, url, wordlist, speed):
        self.wordlist = wordlist
        self.length   = None
        self.speed    = speed
        self.url      = url
        self.i        = 1
        try: 
            self.wordlist_name = self.wordlist.split('/')[-1]
        except:
            self.wordlist_name = "None" 
            
    #Gets total total number of subdomains from file    
    def getFileLength(self):
        try:
            with open(self.wordlist, 'r') as directories:
              length = directories.readlines()
              return str(len(length))
        except:
            return "None"
    
    #Shows options
    def show_options(self):
        print(colored("[*] Available Options:", "green"))
        print(colored("+----------------------+------------------------------------+-------------------------------+", "green"))
        print(colored("| Options              | Current Setting        |  Required        | Description            |", "green"))
        print(colored("+----------------------+------------------------------------+-------------------------------+", "green"))     
        print(colored(f"| target               | {self.url.ljust(23)}|    Yes           | Your Target            |", "cyan"))
        print(colored(f"| wordlist             | {self.wordlist_name.ljust(23)}|    Yes           | your Wordlist          |", "cyan"))
        print(colored(f"| sizeOfWordlist       | {self.getFileLength().ljust(23)}|    IdK           |shows length of wordlist|", "cyan"))
        print(colored(f"| threads              | {str(self.speed).ljust(23)}|    Yes           | Threads                |", "cyan"))
        print(colored("+----------------------+------------------------+------------------+-------------------------+", "green"))

    #Sends requests and analysis response 
    def get(self, url):
        try:
            if self.length == None:
                length = self.getFileLength()
            response = requests.get(url)
            
            
            if response:
                time.sleep(0.01)
                print("".ljust(100), end='\r')
                print(colored(f"[{self.i}/{length}]\t{response.status_code} : {url.ljust(60)} ", 'green'))
                self.subdomain_list.append(url)
                self.i = self.i + 1
            else:
                print(f"[{self.i}/{length}]\t    : {url.ljust(35)} Not Found",end="\r")
                self.i = self.i + 1
        except:
            print(f"[{self.i}/{length}]\t: {url.ljust(35)} Not Found",end="\r")
            self.i = self.i + 1
            pass
        
    # Manages Threads, file and link
    def scanner(self):
        with open(self.wordlist, 'r') as subdomains:
            threads = []
            for subdomain in subdomains.readlines():
                try:
                    subdomain = subdomain.strip('\n')
                    
                    if 'http://' not in self.url and 'http://' not in self.url:
                        test_url = "http://" + self.url
                    test_url = self.url.replace('://', '://' + subdomain + '.')
                    
                    thread = threading.Thread(target=self.get, args=(test_url,))
                    threads.append(thread)
                    thread.start()
                    if len(threads) == self.speed:
                        for thread in threads:
                            thread.join()
                        threads = []
                except KeyboardInterrupt:
                    threads = []
                    print("[*] Exiting....tool")
                    return
        for thread in threads:
            thread.join()
            
    #Runs Wordlist attack        
    def runBruteScan(self):
        print(colored("[+] Started Subdomain scanning...\n",'green'))
        self.scanner()
        print(colored("[+] Finished Subdomain scanning...\n",'green'))






#print(colored("| wordlist             | None                   |     No           | Description of option2 |", "cyan"))
#print(colored("| sizeOfWordlist       | None                   |     No           | Description of option3 |", "cyan"))

