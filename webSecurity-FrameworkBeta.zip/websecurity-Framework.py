
from termcolor import colored
from bs4 import BeautifulSoup as bs
import runClass




'''
directory_wordlist = "wordlists/dirWordlist.txt"
subdomain_wordlist = "wordlists/subdomains_wordlist.txt"

scanner = mainClass.Scanner(url)
crawler = mainClass.Crawler(url)
vulnscanner = mainClass.VulnScanner(url, payload_file)                                                  
dir_scanner = mainClass.dirScanner(url, directory_wordlist, 200)
subdomain_scanner = mainClass.subdomainScanner("freebasics.com", subdomain_wordlist, 220)
def vulnerabilityScanner():
    vulnscanner = mainClass.VulnScanner(url, target, payload_file )
    vulnscanner.login(login_url, login_data)
    vulnscanner.runScanner(20)
    
'''

def banner():
    print(colored("+-------------------------------------------------------------------------+", "green"))
    print(colored("|          WEB SECURITY TOOLKIT by ~Malik_Shoaib                          |", "green"))
    print(colored("+---------------------------+---------------------------------------------+", "green"))
    print(colored("|     __________________    |                                             |", "blue"))
    print(colored("| ==c(______(o(______(_()   | |  ___________  |======[***                 |", "blue"))
    print(colored("|            )=\            | | | WEB SECURITY \ |                        |", "blue"))
    print(colored("|                           | | |  TOOLKIT      \|                        |", "blue"))
    print(colored("|    <Version:1 Alpha>      | | |_____________/\                          |", "blue"))
    print(colored("|                           | |  [_][_][_][_]|                            |", "blue"))
    print(colored("|                           | |  [___________]                            |", "blue"))
    print(colored("|                           | |                                           |", "blue"))
    print(colored("|   IP:    {:<15}  | |  FEATURES:                                |".format("127.0.0.1"), "cyan"))
    print(colored("|   PORT:  {:<15}  | |  - Reconnaissance Tools                   |".format("8080"), "cyan"))
    print(colored("|   TARGET:{:<15}  | |  - Discovery Tools                        |".format("example.com"), "cyan"))
    print(colored("+---------------------------+ |  - Advanced Automation                    |", "green"))
    print(colored("|                             |  - Faster Bug Hunting                     |", "green"))
    print(colored("|  [+] Reconnaissance Tools   |  - Recon-Dog Bot for Automated Recon      |", "green"))
    print(colored("|  [+] Discovery Tools        |                                           |", "green"))
    print(colored("|  [+] Advanced Automation    |  Type 'show list' to see available tools  |", "green"))
    print(colored("|  [+] Faster Bug Hunting     |  Type 'help' for help                     |", "green"))
    print(colored("|  [+] Recon-Dog Bot for      |                                           |", "green"))
    print(colored("|       Automated Recon       |                                           |", "green"))
    print(colored("+-----------------------------+-------------------------------------------+", "green"))

banner()
tool = runClass.Tool()
tool.run()         
            
            

'''
scanner.login(login_url, login_data)
crawler.runSpider()
vulnscanner.runScanner(20)
dir_scanner.runBruteScan()
subdomain_scanner.runBruteScan()

'''