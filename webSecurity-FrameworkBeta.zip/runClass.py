import mainClass
from termcolor import colored
import sys

class Tool():
    def __init__(self):
        self.target = "None"
        self.login_data = {
        'username': 'admin',
        'password': 'password',
        'Login'   : 'submit'
         }
        self.login_url = 'http://localhost:8080/login.php'
        self.url = 'http://localhost:8080/'
        
        self.dirScanner_file = "None"
        self.target_urls = 'wordlists/target_links.txt'
        self.payload_file = 'wordlists/htmlPayloads.txt'
    
    #Check if user entered basic commands
    def basicCommands(self, input_list):
        #Checks if user needs help or not
        if input_list[0] == "-h" or input_list[0] == "--help" or input_list[0] == "help":
            self.show_help()
            
        #Shows list of avaliable tools    
        elif input_list[0] == "show":
            if input_list[1] == "list":
                self.show_list()
            
        #Checks which tool user want to use
        elif input_list[0] == "use": 
            if input_list[1] == "0":
                print(colored("\n[*] Using Link Crawler:", "green"))
                self.crawler()
                print(colored("[*] Exiting Link Crawler:", "green"))
            elif input_list[1] == "1":
                print(colored("\n[*] Using Hidden Paths Scanner:", "green"))
                self.directory_scanner()
                print(colored("[*] Exiting Hidden Paths Scanner:", "green"))
            elif input_list[1] == "2":
                print(colored("\n[*] Using Subdomain Scanner:", "green"))
                self.subdomain_scanner()
                print(colored("[*] Exiting Subdomain Scanner:", "green"))
            elif input_list[1] == "3":
                print(colored("\n[*] Using Vulnerability Scanner:", "green"))
                self.vulnerability_scanner()
                print(colored("[*] Exiting Vulnerability Scanner:", "green"))
        else:
            print(colored("[*] Unknown command : ", "red"), input_list[0])
            
    #Shows list of avaliabe tools    
    def show_list(self):
        print(colored("[*] Available Tools", "green"))
        print(colored("+----+-----------------------------+", "green"))
        print(colored("| ID | Tool Name                   |", "green"))
        print(colored("+----+-----------------------------+", "green"))
        print(colored("| 0  | Link Crawler                |", "cyan"))
        print(colored("| 1  | Hidden Paths Scanner        |", "cyan"))
        print(colored("| 2  | Subdomain Scanner           |", "cyan"))
        print(colored("| 3  | Injection Scanner           |", "cyan"))
        print(colored("+----+-----------------------------+", "green"))
        print(colored("[*] Type 'use <tool_id>' to select a tool", "green"))
        
    #Shows help
    def show_help(self):
        print(colored("[*] Basic Commands:", "green"))
        print(colored("+----------------------+-------------------------------------+", "green"))
        print(colored("| Command              | Description                         |", "green"))
        print(colored("+----------------------+-------------------------------------+", "green"))
        print(colored("| use <tool_id>        | Select a tool to use                |", "cyan"))
        print(colored("| set <option> <value> | Set an option for the selected tool |", "cyan"))
        print(colored("| run                  | Run the selected tool               |", "cyan"))
        print(colored("| show options         | Show options for the selected tool  |", "cyan"))
        print(colored("| show list            | Show available tools                |", "cyan"))
        print(colored("| help                 | Show this help message              |", "cyan"))
        print(colored("+----------------------+-------------------------------------+", "green"))
    
    #Sets options
    def set_option(self, option, value):
        print(colored("[*] Setting {} to {}".format(option, value), "green"))
    
    #Runs directory_scanner    
    def directory_scanner(self):
        speed  = "80"
        target = "http://google.com/"
        dirScanner_file = "wordlists/dirWordlist.txt"
        dir_scan_obj = mainClass.dirScanner(target, dirScanner_file, speed)                      
        while True:
            usrInput = input(colored("---(DirScanner~):", 'red'))
            input_list = usrInput.split(" ")
            
            #Runs Basic Commands:
            self.basicCommands(input_list)
            #Checks if user want to exit
            if usrInput == "exit":
                break
            
            #Shows options:
            if input_list[0] == "show":
                if input_list[1] == "options":
                    dir_scan_obj.show_options()
            
            #Sets Target        
            if input_list[0] == "set":
                if input_list[1] == "target":
                    target = input_list[2]
                    if "http://" not in input_list[2] and "https://" not in input_list[2]:
                        target = "http://" + target
                    if input_list[2][-1] != "/":
                        target = target + '/'
                    self.set_option(input_list[1], target)
                elif input_list[1] == "wordlist":
                    dirScanner_file = input_list[2]
                    self.set_option(input_list[1], input_list[2])
                elif input_list[1] == "threads":
                    speed = int(input_list[2])
                    self.set_option(input_list[1], input_list[2])
            
            #Executes attack
            if usrInput == "run":
                if target == "None" and dirScanner_file == "None" and speed == "None":
                    print("[*] Set Required options before starting!")
                else:
                    dir_scan_obj.runBruteScan()
                    
            dir_scan_obj = mainClass.dirScanner(target, dirScanner_file, speed)    
            
    #Runs Crawler    
    def crawler(self):
        target = "http://localhost:8080/"
        crawl_obj = mainClass.Crawler(target)
        while True:
            usrInput = input(colored("---(Crawler~):", 'red'))
            input_list = usrInput.split(" ")
            
            #Runs Basic Commands:
            self.basicCommands(input_list)
            #Checks if user want to exit
            if usrInput == "exit":
                break
            
            #Shows options:
            if input_list[0] == "show":
                if input_list[1] == "options":
                    crawl_obj.show_options()
            
            #Sets Target        
            if input_list[0] == "set":
                if input_list[1] == "target":
                    target = input_list[2]
                    if "http://" not in input_list[2] and "https://" not in input_list[2]:
                        target = "http://" + target
                    if input_list[2][-1] != "/":
                        target = target + '/'
                    self.set_option(input_list[1], target)
                    
            if usrInput == "run":
                if target == "None":
                    print("[*] Set Target before crawling")
                else:
                    crawl_obj.runSpider()
            crawl_obj = mainClass.Crawler(str(target))
            
            if usrInput == "login":
                crawl_obj.login(self.login_url, self.login_data)
                
    #Runs subdomain scanner            
    def subdomain_scanner(self):
        speed  = '80'
        target = "google.com"
        subScanner_file = "wordlists/subdomains_wordlist.txt"
        sub_scan_obj = mainClass.subdomainScanner(target, subScanner_file, speed)                      
        while True:
            usrInput = input(colored("==(Subdomain-Scanner~):", 'red'))
            input_list = usrInput.split(" ")
            
            #Runs Basic Commands:
            self.basicCommands(input_list)
            #Checks if user want to exit
            if usrInput == "exit":
                break
            
            #Shows options:
            if input_list[0] == "show":
                if input_list[1] == "options":
                    sub_scan_obj.show_options()
            
            #Sets Target        
            if input_list[0] == "set":
                if input_list[1] == "target":
                    target = input_list[2]
                    if "http://" not in input_list[2] and "https://" not in input_list[2]:
                        target = "http://" + target
                    if input_list[2][-1] != "/":
                        target = target + '/'
                    self.set_option(input_list[1], target)
                elif input_list[1] == "wordlist":
                    subScanner_file = input_list[2]
                    self.set_option(input_list[1], subScanner_file)
                elif input_list[1] == "threads":
                    speed = int(input_list[2])
                    self.set_option(input_list[1], speed)
            
            #Executes attack
            if usrInput == "run":
                if target == "None" and subScanner_file == "None" and speed == "None":
                    print("[*] Set Required options before starting!")
                else:
                    sub_scan_obj.runBruteScan()
                    
            sub_scan_obj = mainClass.subdomainScanner(target, subScanner_file, speed)    
            
    #Runs VulnerabilityScanner
    def vulnerability_scanner(self):
        #speed  = "80"
        target = "None"
        target_urls  = "wordlists/target_links.txt"
        payload_file = "wordlists/Payloads.txt"
        vul_scan_obj = mainClass.VulnScanner(target, target_urls, payload_file)                      
        while True:
            usrInput = input(colored("==(VULNERABILITY SCANNER~):", 'red'))
            input_list = usrInput.split(" ")
            
            #Runs Basic Commands:
            self.basicCommands(input_list)
            #Checks if user want to exit
            if usrInput == "exit":
                break
            
            #Shows options:
            if input_list[0] == "show":
                if input_list[1] == "options":
                    vul_scan_obj.show_options()
            
            #Sets Target        
            if input_list[0] == "set":
                if input_list[1] == "target_urls":
                    target_urls = input_list[2]
                    self.set_option(input_list[1], target)
                elif input_list[1] == "payload_file":
                    payload_file = input_list[2]
                    self.set_option(input_list[1], input_list[2])
            
            #Executes attack
            if usrInput == "run":
                if target_urls == "None" and payload_file == "None":
                    print("[*] Set Required options before starting!")
                else:
                    vul_scan_obj.runScanner(1)
            
            if usrInput == "login":
                vul_scan_obj.login(self.login_url, self.login_data)
           
                    
            vul_scan_obj = mainClass.VulnScanner(target, target_urls, payload_file)    
            
    
    #It runs controller
    def run(self):
        while True:
            #Gets input from user
            usrInput = input(colored("  ~Enter Command:", 'red'))
            input_list = usrInput.split(" ")
            if input_list[0] =='exit':
                sys.exit(0)
            check = self.basicCommands(input_list)
            if check == False:
                print('hello')
            
